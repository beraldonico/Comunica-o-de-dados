clear all

passo = 1e-5; %passo da simulação
tempo_total = 5;  % tempo da simulação (em segundos)
tempo = 0:passo:tempo_total;

% CRIAR SINAL (y)
[Y,wav_fs] = audioread("signal_in.wav");
ywav = Y(:,1); % pegar só um canal
%y = Y(1:30000,1); % pegar primeiros valores (caso haja problemas de memória em pegar todos) e só um canal;
ywav = ywav'; 
wav_passo = 1/wav_fs;
twav = 0:wav_passo:wav_passo*(length(ywav)-1);

% converter para passo do WAV para passo da simulação
k = 1;
for i=1:length(tempo) 
    if (k>=length(ywav))
       sinal(i) = 0;
    else
        if (twav(k) < tempo(i))
      	    k = k + 1;
        end  
        sinal(i) = ywav(k);
    end
end
#plot sinal
subplot(4,2,1);
plot(tempo, sinal);
title("sinal");
xlabel("tempo");
ylabel("tensao");

% FFT sinal
[f_s, p_s] = fft_fun(sinal, passo);
subplot(4,2,2);
plot(f_s, p_s);
title("FFT sinal");
xlabel("frequencia");

#sinal limitado a 2kHz 
Fs = 1/passo;
cutoff_freq = 2000;
Fnorm = 2*cutoff_freq/Fs;
[b, a] = butter(5, Fnorm);
sinal_2k = filter(b, a, sinal);
subplot(4,2,3);
plot(tempo, sinal_2k);
title("sinal limitado a 2kHz");
xlabel("tempo");
ylabel("tensao");

% FFT audio 2kHz
[f_s2k, p_s2k] = fft_fun(sinal_2k, passo);
subplot(4,2,4);
plot(f_s2k, p_s2k);
title("FFT sinal limitado");
xlabel("frequencia");

% CRIAR PORTADORA (c)
freq_port = 1000;
portadora = sin(2*pi*freq_port*tempo);
subplot(4,2,5);
plot(tempo, portadora);
title("portadora");
xlabel("tempo");
ylabel("tensao");

#FFT portadora
[f_port, p_port] = fft_fun(portadora, passo);
subplot(4,2,6);
plot(f_port, p_port);
title("FFT portadora");
xlabel("frequencia");

% CRIAR SINAL MODULADO (m)
modulado = portadora.*sinal_2k;
subplot(4,2,7);
plot(tempo, modulado);
title("modulado");
xlabel("tempo");
ylabel("tensao");

% FFT modulado
[f_mod, p_mod] = fft_fun(modulado, passo);
subplot(4,2,8);
plot(f_mod, p_mod);
title("FFT modulado");
xlabel("frequencia");