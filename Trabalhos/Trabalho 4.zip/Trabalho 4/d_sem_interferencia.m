clear all

passo = 1e-5; %passo da simulação
tempo_total = 5;  % tempo da simulação (em segundos)
tempo = 0:passo:tempo_total;

##########################################SINAL 1###################################################
% CRIAR SINAL (y)
[Y,wav_fs] = audioread("signal_in1.wav");
ywav = Y(:,1); % pegar só um canal
%y = Y(1:30000,1); % pegar primeiros valores (caso haja problemas de memória em pegar todos) e só um canal;
ywav = ywav'; 
wav_passo = 1/wav_fs;
twav = 0:wav_passo:wav_passo*(length(ywav)-1);

% converter para passo do WAV para passo da simulação
k = 1;
for i=1:length(tempo) 
    if (k>=length(ywav))
       sinal1(i) = 0;
    else
        if (twav(k) < tempo(i))
      	    k = k + 1;
        end  
        sinal1(i) = ywav(k);
    end
end

##########################################SINAL 2###################################################
% CRIAR SINAL (y)
[Y,wav_fs] = audioread("signal_in2.wav");
ywav = Y(:,1); % pegar só um canal
%y = Y(1:30000,1); % pegar primeiros valores (caso haja problemas de memória em pegar todos) e só um canal;
ywav = ywav'; 
wav_passo = 1/wav_fs;
twav = 0:wav_passo:wav_passo*(length(ywav)-1);

% converter para passo do WAV para passo da simulação
k = 1;
for i=1:length(tempo) 
    if (k>=length(ywav))
       sinal2(i) = 0;
    else
        if (twav(k) < tempo(i))
      	    k = k + 1;
        end  
        sinal2(i) = ywav(k);
    end
end

##########################################SINAL 3###################################################
% CRIAR SINAL (y)
[Y,wav_fs] = audioread("signal_in3.wav");
ywav = Y(:,1); % pegar só um canal
%y = Y(1:30000,1); % pegar primeiros valores (caso haja problemas de memória em pegar todos) e só um canal;
ywav = ywav'; 
wav_passo = 1/wav_fs;
twav = 0:wav_passo:wav_passo*(length(ywav)-1);

% converter para passo do WAV para passo da simulação
k = 1;
for i=1:length(tempo) 
    if (k>=length(ywav))
       sinal3(i) = 0;
    else
        if (twav(k) < tempo(i))
      	    k = k + 1;
        end  
        sinal3(i) = ywav(k);
    end
end

figure('name', 'sinal in');
#plot sinal 1
subplot(3,2,1);
plot(tempo, sinal1);
title("sinal1");
xlabel("tempo");
ylabel("tensao");

% FFT sinal 1
[f_s, p_s] = fft_fun(sinal1, passo);
subplot(3,2,2);
plot(f_s, p_s);
title("FFT sinal1");
xlabel("frequencia");

#plot sinal 2
subplot(3,2,3);
plot(tempo, sinal2);
title("sinal2");
xlabel("tempo");
ylabel("tensao");

% FFT sinal 2
[f_s, p_s] = fft_fun(sinal2, passo);
subplot(3,2,4);
plot(f_s, p_s);
title("FFT sinal2");
xlabel("frequencia");

#plot sinal 3
subplot(3,2,5);
plot(tempo, sinal3);
title("sinal3");
xlabel("tempo");
ylabel("tensao");

% FFT sinal 3
[f_s, p_s] = fft_fun(sinal3, passo);
subplot(3,2,6);
plot(f_s, p_s);
title("FFT sinal3");
xlabel("frequencia");

figure('name', 'sinal in limitado a 2kHz');
#sinal limitado a 2kHz 
Fs = 1/passo;
cutoff_freq = 2000;
Fnorm = 2*cutoff_freq/Fs;
[b, a] = butter(5, Fnorm);
sinal_2k1 = filter(b, a, sinal1);
sinal_2k2 = filter(b, a, sinal2);
sinal_2k3 = filter(b, a, sinal3);
subplot(3,2,1);
plot(tempo, sinal_2k1);
title("sinal 1 limitado a 2kHz");
xlabel("tempo");
ylabel("tensao");
subplot(3,2,3);
plot(tempo, sinal_2k2);
title("sinal 2 limitado a 2kHz");
xlabel("tempo");
ylabel("tensao");
subplot(3,2,5);
plot(tempo, sinal_2k3);
title("sinal 3 limitado a 2kHz");
xlabel("tempo");
ylabel("tensao");

% FFT audio 2kHz
[f_s2k, p_s2k] = fft_fun(sinal_2k1, passo);
subplot(3,2,2);
plot(f_s2k, p_s2k);
title("FFT sinal 1 limitado");
xlabel("frequencia");
[f_s2k, p_s2k] = fft_fun(sinal_2k2, passo);
subplot(3,2,4);
plot(f_s2k, p_s2k);
title("FFT sinal 2 limitado");
xlabel("frequencia");
[f_s2k, p_s2k] = fft_fun(sinal_2k3, passo);
subplot(3,2,6);
plot(f_s2k, p_s2k);
title("FFT sinal 3 limitado");
xlabel("frequencia");

figure('name', 'portadoras');
% CRIAR PORTADORA (c)
guard_band = 3000;
band_width = 5000;

freq_port1 = 5000;
freq_port2 = freq_port1+guard_band+band_width;
freq_port3 = freq_port2+guard_band+band_width;

portadora1 = sin(2*pi*freq_port1*tempo);
portadora2 = sin(2*pi*freq_port2*tempo);
portadora3 = sin(2*pi*freq_port3*tempo);
subplot(3,2,1);
plot(tempo, portadora1);
title("portadora 1");
xlabel("tempo");
ylabel("tensao");
subplot(3,2,3);
plot(tempo, portadora2);
title("portadora 1");
xlabel("tempo");
ylabel("tensao");
subplot(3,2,5);
plot(tempo, portadora3);
title("portadora 3");
xlabel("tempo");
ylabel("tensao");

#FFT portadora
[f_port, p_port] = fft_fun(portadora1, passo);
subplot(3,2,2);
plot(f_port, p_port);
title("FFT portadora 1");
xlabel("frequencia");
[f_port, p_port] = fft_fun(portadora2, passo);
subplot(3,2,4);
plot(f_port, p_port);
title("FFT portadora 2");
xlabel("frequencia");
[f_port, p_port] = fft_fun(portadora3, passo);
subplot(3,2,6);
plot(f_port, p_port);
title("FFT portadora 3");
xlabel("frequencia");

figure('name', 'modulados');
% CRIAR SINAL MODULADO (m)
modulado1 = portadora1.*sinal_2k1;
modulado2 = portadora2.*sinal_2k2;
modulado3 = portadora3.*sinal_2k3;
subplot(3,2,1);
plot(tempo, modulado1);
title("modulado 1");
xlabel("tempo");
ylabel("tensao");
subplot(3,2,3);
plot(tempo, modulado2);
title("modulado 2");
xlabel("tempo");
ylabel("tensao");
subplot(3,2,5);
plot(tempo, modulado3);
title("modulado 3");
xlabel("tempo");
ylabel("tensao");

% FFT modulado
[f_mod, p_mod] = fft_fun(modulado1, passo);
subplot(3,2,2);
plot(f_mod, p_mod);
title("FFT modulado 1");
xlabel("frequencia");
[f_mod, p_mod] = fft_fun(modulado2, passo);
subplot(3,2,4);
plot(f_mod, p_mod);
title("FFT modulado 2");
xlabel("frequencia");
[f_mod, p_mod] = fft_fun(modulado3, passo);
subplot(3,2,6);
plot(f_mod, p_mod);
title("FFT modulado 3");
xlabel("frequencia");

figure('name', 'multiplexado');
% MULTIPLEXACAO
multiplexado = modulado1+modulado2+modulado3;
subplot(4,2,1);
plot(tempo, multiplexado);
title("multiplexado");

% PLOT FFT SINAL MULTIPLEXADO
[f_multi, p_multi] = fft_fun(multiplexado, passo);
subplot(4,2,2);
plot(f_multi, p_multi);
title("FFT multiplexado");

% FILTROS PASSA BANDAS 
% MENSAGEM 1
cutoff_lb = 2*(freq_port1-band_width/2);
cutoff_ub = 2*(freq_port1+band_width/2);

lFnorm = cutoff_lb/Fs;
uFnorm = cutoff_ub/Fs;

[b, a] = butter(4, [lFnorm, uFnorm]);

demulti_1 = filter(b, a, multiplexado);
subplot(4,2,3);
plot(tempo, demulti_1);
title("demulti 1 ");
xlabel("tempo");
ylabel("tensao");

% MENSAGEM 2
cutoff_lb = 2*(freq_port2-band_width/2);
cutoff_ub = 2*(freq_port2+band_width/2);

lFnorm = cutoff_lb/Fs;
uFnorm = cutoff_ub/Fs;

[b, a] = butter(4, [lFnorm, uFnorm]);

demulti_2 = filter(b, a, multiplexado);
subplot(4,2,5);
plot(tempo, demulti_2);
title("demulti 2");
xlabel("tempo");
ylabel("tensao");

% MENSAGEM 3
cutoff_lb = 2*(freq_port3-band_width/2);
cutoff_ub = 2*(freq_port3+band_width/2);

lFnorm = cutoff_lb/Fs;
uFnorm = cutoff_ub/Fs;

[b, a] = butter(4, [lFnorm, uFnorm]);

demulti_3 = filter(b, a, multiplexado);
subplot(4,2,7);
plot(tempo, demulti_3);
title("demulti 3");
xlabel("tempo");
ylabel("tensao");
% ...
% PLOT PASSA BANDAS
[f, p] = fft_fun(demulti_1, passo);
subplot(4,2,4);
plot(f, p);
title("Sinal composto filtrado banda 1");

[f, p] = fft_fun(demulti_2, passo);
subplot(4,2,6);
plot(f, p);
title("Sinal composto filtrado banda 2");

[f, p] = fft_fun(demulti_3, passo);
subplot(4,2,8);
plot(f, p);
title("Sinal composto filtrado banda 3");

figure( 'name', 'demodulador')
% DEMODULACAO 
% MIXER 
coerente1 = demulti_1.*portadora1;
coerente2 = demulti_2.*portadora2;
coerente3 = demulti_3.*portadora3;

% FILTRO PASSA BAIXAS
Fs = 1/passo;
cutoff_freq = freq_port1;
Fnorm = 2*cutoff_freq/Fs;
[b, a] = butter(5, Fnorm);
demodulado1 = filter(b, a, coerente1);
subplot(3, 1, 1);
plot(tempo, demodulado1);
title("demodulado 1");
xlabel("tempo");
ylabel("tensao");

Fs = 1/passo;
cutoff_freq = freq_port2;
Fnorm = 2*cutoff_freq/Fs;
[b, a] = butter(5, Fnorm);
demodulado2 = filter(b, a, coerente2);
subplot(3, 1, 2);
plot(tempo, demodulado2);
title("demodulado 2");
xlabel("tempo");
ylabel("tensao");

Fs = 1/passo;
cutoff_freq = freq_port3;
Fnorm = 2*cutoff_freq/Fs;
[b, a] = butter(5, Fnorm);
demodulado3 = filter(b, a, coerente3);
subplot(3, 1, 3);
plot(tempo, demodulado3);
title("demodulado 3");
xlabel("tempo");
ylabel("tensao");

% criar arquivo
audiowrite("signal_out1.wav", demodulado1, 1/passo);
audiowrite("signal_out2.wav", demodulado2, 1/passo);
audiowrite("signal_out3.wav", demodulado3, 1/passo);